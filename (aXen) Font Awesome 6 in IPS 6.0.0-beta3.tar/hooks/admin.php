//<?php

/* To prevent PHP errors (extending class does not exist) revealing path */
if (!\defined('\IPS\SUITE_UNIQUE_KEY')) {
    exit;
}

class axenfontawesome6_hook_admin extends _HOOK_CLASS_
{

/* !Hook Data - DO NOT REMOVE */
    public static function hookData()
    {
        return array_merge_recursive(array(
            'globalTemplate' => array(
                0 => array(
                    'selector' => 'html > head',
                    'type' => 'add_inside_end',
                    'content' => '
{{$fa6All = \IPS\Theme::i()->css( \'all.css\', \'axenfontawesome6\', \'global\' );}}
{{$fa6FontFace4 = \IPS\Theme::i()->css( \'v4-font-face.css\', \'axenfontawesome6\', \'global\' );}}
{{$customCssArray = [$fa6All, $fa6FontFace4]; }}
{{foreach $customCssArray as $customCss}}
{{foreach $customCss as $css}}
<link rel=\'stylesheet\' href=\'{expression="\IPS\Http\Url::external( $css )->setQueryString( \'v\', \IPS\Theme::i()->cssCacheBustKey() )"}\' media=\'all\'>
{{endforeach}}
{{endforeach}}
',
                ),
            ),
        ), parent::hookData());
    }
/* End Hook Data */

}

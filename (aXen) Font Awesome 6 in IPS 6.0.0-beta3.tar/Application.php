<?php
/**
 * @brief        (aXen) Font Awesome 6 in IPS Application Class
 * @author        <a href='https://axendev.net/'>aXenDev</a>
 * @copyright    (c) 2022 aXenDev
 * @package        Invision Community
 * @subpackage    (aXen) Font Awesome 6 in IPS
 * @since        03 Feb 2022
 * @version
 */

namespace IPS\axenfontawesome6;

/**
 * (aXen) Font Awesome 6 in IPS Application Class
 */
class _Application extends \IPS\Application

{

}

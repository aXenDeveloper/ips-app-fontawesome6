# (aXen) Font Awesome 6 in IPS in IPS

# Update code

## fa-brands-400.ttf

```
../webfonts/fa-brands-400.ttf
```

to:

```
{resource='fa-brands-400.ttf' app='axenfontawesome6' location='global'}
```

## fa-brands-400.woff2

```
../webfonts/fa-brands-400.woff2
```

to:

```
{resource='fa-brands-400.woff2' app='axenfontawesome6' location='global'}
```

## fa-regular-400.ttf

```
../webfonts/fa-regular-400.ttf
```

to:

```
{resource='fa-regular-400.ttf' app='axenfontawesome6' location='global'}
```

## fa-regular-400.woff2

```
../webfonts/fa-regular-400.woff2
```

to:

```
{resource='fa-regular-400.woff2' app='axenfontawesome6' location='global'}
```

## fa-solid-900.ttf

```
../webfonts/fa-solid-900.ttf
```

to:

```
{resource='fa-solid-900.ttf' app='axenfontawesome6' location='global'}
```

## fa-solid-900.woff2

```
../webfonts/fa-solid-900.woff2
```

to:

```
{resource='fa-solid-900.woff2' app='axenfontawesome6' location='global'}
```

## fa-v4compatibility.ttf

```
../webfonts/fa-v4compatibility.ttf
```

to:

```
{resource='fa-v4compatibility.ttf' app='axenfontawesome6' location='global'}
```

## fa-v4compatibility.woff2

```
../webfonts/fa-v4compatibility.woff2
```

to:

```
{resource='fa-v4compatibility.woff2' app='axenfontawesome6' location='global'}
```
